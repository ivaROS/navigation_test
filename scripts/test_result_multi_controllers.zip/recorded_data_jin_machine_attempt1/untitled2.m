clear; clc;
num_test_3_barrels = 50;
num_test_5_barrels = 50;
success_count_3_barrels = [0 0 0 0 0 0 0 0];
success_count_5_barrels = [0 0 0 0 0 0 0 0];
success_count_7_barrels = [0 0 0 0 0 0 0 0];
for i = 1 : num_test_3_barrels
    filename = strcat('data_', int2str(i), '_numbarrels_3.csv');
    fp = importfile(filename);
    for j = 2 : 2: 16
        result = fp{j, 2}(3);
        if (result == 's')
            success_count_3_barrels(j / 2) = success_count_3_barrels(j / 2) + 1;
        end
    end
end


for i = 1 : num_test_5_barrels
    filename = strcat('data_', int2str(i), '_numbarrels_5.csv');
    fp = importfile(filename);
    for j = 2 : 2: 16
        result = fp{j, 2}(3);
        if (result == 's')
            success_count_5_barrels(j / 2) = success_count_5_barrels(j / 2) + 1;
        end
    end
end

for i = 1 : num_test_5_barrels
    filename = strcat('data_', int2str(i), '_numbarrels_5.csv');
    fp = importfile(filename);
    for j = 2 : 2: 16
        result = fp{j, 2}(3);
        if (result == 's')
            success_count_7_barrels(j / 2) = success_count_7_barrels(j / 2) + 1;
        end
    end
end

total = [success_count_3_barrels'.*2  success_count_5_barrels'.*2 success_count_7_barrels'.*2];
x = [3, 5, 7];

h = zeros(1, 16);
h(1) = plot(x, total(1,:), 'm--');
hold on
h(2) = plot(x, total(1,:), 'mo');
hold on
h(3) = plot(x, total(2,:), 'b-');
hold on
h(4) = plot(x, total(2,:), 'b*');
hold on
h(5) = plot(x, total(3,:), 'c-.'); 
hold on
h(6) = plot(x, total(3,:), 'cx');
hold on
h(7) = plot(x, total(4,:), 'b:');
hold on
h(8) = plot(x, total(4,:), 'bs');
hold on
h(9) = plot(x, total(5,:), 'm:');
hold on
h(10) = plot(x, total(5,:), 'md');
hold on
h(11) = plot(x, total(6,:), 'g-'); 
hold on
h(12) = plot(x, total(6,:), 'gv');
hold on
h(13) = plot(x, total(7,:), 'r--');
hold on
h(14) = plot(x, total(7,:), 'rp');
hold on
h(15) = plot(x, total(8,:), 'k:'); 
hold on
h(16) = plot(x, total(8,:), 'kx');
hold on
axis([2, 8, 50, 105]);
hold on
legend(h(2:2:16), 'DWA', 'EBAND', 'TEB', 'LPIPS-TOGOAL', 'LPIPS-GOALBIAS', 'LCARTESIAN-TOGOAl', ...
    'LCARTESIAN-GOALBIAS', 'NAIVE-GOALBIAS');
hold on
title('Navigation Success Rate of Each Planner');
hold on
xlabel('Number of Barrels');
hold on
ylabel('Success Rate (%)');